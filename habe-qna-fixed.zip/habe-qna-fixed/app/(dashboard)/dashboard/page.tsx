import { createClient } from "@/lib/supabase/server"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { QuestionCard } from "@/components/questions/question-card"
import { MessageCircleQuestion, TrendingUp, Users, Plus, ArrowRight } from "lucide-react"

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: recentQuestions } = await supabase
    .from("questions")
    .select(`*, profile:profiles!questions_user_id_fkey(id, full_name, role)`)
    .order("created_at", { ascending: false })
    .limit(5)

  const { count: totalQuestions } = await supabase
    .from("questions")
    .select("*", { count: "exact", head: true })

  const { count: totalAnswers } = await supabase
    .from("answers")
    .select("*", { count: "exact", head: true })

  const { count: myQuestions } = await supabase
    .from("questions")
    .select("*", { count: "exact", head: true })
    .eq("user_id", user?.id)

  const stats = [
    {
      title: "Total Questions",
      value: totalQuestions || 0,
      icon: MessageCircleQuestion,
      description: "Questions in the community",
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      title: "Total Answers",
      value: totalAnswers || 0,
      icon: TrendingUp,
      description: "Answers provided",
      color: "text-accent",
      bg: "bg-accent/10",
    },
    {
      title: "My Questions",
      value: myQuestions || 0,
      icon: Users,
      description: "Questions you've asked",
      color: "text-success",
      bg: "bg-success/10",
    },
  ]

  return (
    <div className="space-y-8 max-w-5xl">
      {/* Page header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground text-sm mt-0.5">
            {"Welcome back! Here's what's happening."}
          </p>
        </div>
        <Button size="sm" className="bg-primary hover:bg-primary/90 shadow-md shadow-primary/20 w-fit" asChild>
          <Link href="/questions/ask">
            <Plus className="h-4 w-4 mr-1.5" />
            Ask Question
          </Link>
        </Button>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        {stats.map((stat) => (
          <Card key={stat.title} className="border-border/60">
            <CardHeader className="flex flex-row items-center justify-between pb-2 pt-5 px-5">
              <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
              <div className={`w-8 h-8 rounded-lg ${stat.bg} flex items-center justify-center`}>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent className="px-5 pb-5">
              <div className="text-3xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground mt-0.5">{stat.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent Questions */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold">Recent Questions</h2>
          <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground gap-1 h-8" asChild>
            <Link href="/questions">
              View all
              <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </Button>
        </div>

        {recentQuestions && recentQuestions.length > 0 ? (
          <div className="space-y-3">
            {recentQuestions.map((question) => (
              <QuestionCard key={question.id} question={question} currentUserId={user?.id} />
            ))}
          </div>
        ) : (
          <Card className="border-dashed border-border/60">
            <CardContent className="flex flex-col items-center justify-center py-14">
              <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center mb-4">
                <MessageCircleQuestion className="h-7 w-7 text-muted-foreground" />
              </div>
              <CardTitle className="mb-1.5 text-base">No questions yet</CardTitle>
              <CardDescription className="text-center mb-5 max-w-xs">
                Be the first to ask a question and start the conversation!
              </CardDescription>
              <Button size="sm" asChild>
                <Link href="/questions/ask">
                  <Plus className="h-4 w-4 mr-1.5" />
                  Ask the First Question
                </Link>
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
