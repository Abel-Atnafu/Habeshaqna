import { createClient } from "@/lib/supabase/server"
import { notFound } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { formatDistanceToNow } from "date-fns"
import { ArrowLeft, MessageCircle } from "lucide-react"
import { VoteButtons } from "@/components/questions/vote-buttons"
import { AnswerForm } from "@/components/questions/answer-form"
import { AnswerCard } from "@/components/questions/answer-card"
import { cn } from "@/lib/utils"

export default async function QuestionDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: question } = await supabase
    .from("questions")
    .select(`*, profile:profiles!questions_user_id_fkey(id, full_name, role)`)
    .eq("id", id)
    .single()

  if (!question) notFound()

  const { data: answers } = await supabase
    .from("answers")
    .select(`*, profile:profiles!answers_user_id_fkey(id, full_name, role)`)
    .eq("question_id", id)
    .order("is_accepted", { ascending: false })
    .order("created_at", { ascending: true })

  const { data: questionVotes } = await supabase
    .from("votes")
    .select("value")
    .eq("question_id", id)

  const questionVoteScore = questionVotes?.reduce((sum, vote) => sum + vote.value, 0) || 0

  let userQuestionVote = 0
  if (user) {
    const { data: myVote } = await supabase
      .from("votes")
      .select("value")
      .eq("question_id", id)
      .eq("user_id", user.id)
      .single()
    userQuestionVote = myVote?.value || 0
  }

  const displayName = question.is_anonymous
    ? "Anonymous"
    : question.profile?.full_name || "Unknown User"
  const initials = displayName.slice(0, 1).toUpperCase()
  const isTeacher = question.profile?.role === "teacher"
  const isOwner = user?.id === question.user_id

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      {/* Back button */}
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="sm" className="gap-1.5 text-muted-foreground hover:text-foreground h-8" asChild>
          <Link href="/questions">
            <ArrowLeft className="h-4 w-4" />
            Back to Questions
          </Link>
        </Button>
      </div>

      {/* Question card */}
      <Card className="border-border/60">
        <CardContent className="p-6">
          <div className="flex gap-5">
            <VoteButtons
              type="question"
              id={question.id}
              score={questionVoteScore}
              userVote={userQuestionVote}
              isLoggedIn={!!user}
            />
            <div className="flex-1 min-w-0">
              {/* Title + status */}
              <div className="flex items-start justify-between gap-3 mb-3">
                <h1 className="text-xl font-bold leading-snug">{question.title}</h1>
                {question.status !== "open" && (
                  <Badge variant={question.status === "answered" ? "default" : "secondary"} className="shrink-0">
                    {question.status === "answered" ? "Answered" : "Closed"}
                  </Badge>
                )}
              </div>

              {/* Author */}
              <div className="flex items-center gap-2 mb-4">
                <div className={cn(
                  "w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold",
                  isTeacher ? "bg-accent/20 text-accent" : "bg-primary/10 text-primary"
                )}>
                  {initials}
                </div>
                <span className="text-sm text-muted-foreground">
                  {displayName}
                  {isOwner && !question.is_anonymous && <span className="text-muted-foreground/60"> (you)</span>}
                </span>
                {isTeacher && !question.is_anonymous && (
                  <Badge variant="secondary" className="text-xs h-4 px-1.5">Teacher</Badge>
                )}
                <span className="text-xs text-muted-foreground/60">
                  asked {formatDistanceToNow(new Date(question.created_at), { addSuffix: true })}
                </span>
              </div>

              {/* Body */}
              <p className="text-sm leading-relaxed whitespace-pre-wrap text-foreground/90">
                {question.body}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Answers section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold flex items-center gap-2">
            <MessageCircle className="h-4 w-4 text-muted-foreground" />
            {answers?.length || 0} {answers?.length === 1 ? "Answer" : "Answers"}
          </h2>
        </div>

        {answers && answers.length > 0 ? (
          <div className="space-y-3">
            {answers.map((answer) => (
              <AnswerCard
                key={answer.id}
                answer={answer}
                questionUserId={question.user_id}
                currentUserId={user?.id}
              />
            ))}
          </div>
        ) : (
          <Card className="border-dashed border-border/60">
            <CardContent className="py-10 text-center">
              <p className="text-muted-foreground text-sm">No answers yet. Be the first to help!</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Answer form / sign-in prompt */}
      {user ? (
        <AnswerForm questionId={question.id} />
      ) : (
        <Card className="border-border/60">
          <CardContent className="py-8 text-center">
            <p className="text-muted-foreground text-sm mb-4">Sign in to answer this question</p>
            <Button size="sm" asChild>
              <Link href="/auth/login">Sign In</Link>
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
