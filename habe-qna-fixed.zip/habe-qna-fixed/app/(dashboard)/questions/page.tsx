import { createClient } from "@/lib/supabase/server"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardTitle } from "@/components/ui/card"
import { QuestionCard } from "@/components/questions/question-card"
import { MessageCircleQuestion, Plus } from "lucide-react"

export default async function QuestionsPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: questions } = await supabase
    .from("questions")
    .select(`*, profile:profiles!questions_user_id_fkey(id, full_name, role)`)
    .order("created_at", { ascending: false })

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">All Questions</h1>
          <p className="text-muted-foreground text-sm mt-0.5">
            Browse and answer questions from the community
          </p>
        </div>
        <Button size="sm" className="bg-primary hover:bg-primary/90 shadow-md shadow-primary/20 w-fit" asChild>
          <Link href="/questions/ask">
            <Plus className="h-4 w-4 mr-1.5" />
            Ask Question
          </Link>
        </Button>
      </div>

      {questions && questions.length > 0 ? (
        <div className="space-y-3">
          {questions.map((question) => (
            <QuestionCard key={question.id} question={question} currentUserId={user?.id} />
          ))}
        </div>
      ) : (
        <Card className="border-dashed border-border/60">
          <CardContent className="flex flex-col items-center justify-center py-14">
            <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center mb-4">
              <MessageCircleQuestion className="h-7 w-7 text-muted-foreground" />
            </div>
            <CardTitle className="mb-1.5 text-base">No questions yet</CardTitle>
            <CardDescription className="text-center mb-5 max-w-xs">
              Be the first to ask a question and start the conversation!
            </CardDescription>
            <Button size="sm" asChild>
              <Link href="/questions/ask">
                <Plus className="h-4 w-4 mr-1.5" />
                Ask the First Question
              </Link>
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
