"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { createClient } from "@/lib/supabase/client"
import { Loader2, ArrowLeft, Shield, Lightbulb } from "lucide-react"

export default function AskQuestionPage() {
  const [title, setTitle] = useState("")
  const [body, setBody] = useState("")
  const [isAnonymous, setIsAnonymous] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)

    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      setError("You must be logged in to ask a question")
      setLoading(false)
      return
    }

    const { data, error: insertError } = await supabase
      .from("questions")
      .insert({ user_id: user.id, title, body, is_anonymous: isAnonymous })
      .select()
      .single()

    if (insertError) {
      setError(insertError.message)
      setLoading(false)
      return
    }

    router.push(`/questions/${data.id}`)
    router.refresh()
  }

  return (
    <div className="max-w-2xl space-y-6">
      {/* Back nav */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg" asChild>
          <Link href="/questions">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Ask a Question</h1>
          <p className="text-muted-foreground text-sm">Get help from teachers and students</p>
        </div>
      </div>

      {/* Tips card */}
      <div className="flex gap-3 p-4 rounded-xl bg-primary/5 border border-primary/15">
        <Lightbulb className="h-4 w-4 text-primary shrink-0 mt-0.5" />
        <div className="text-sm text-muted-foreground leading-relaxed">
          <strong className="text-foreground">Tips for a great question:</strong> Be specific, include what you've tried, and provide enough context for others to understand your problem.
        </div>
      </div>

      <Card className="border-border/60">
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
              <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm">
                {error}
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="title" className="text-sm font-medium">Question Title</Label>
              <Input
                id="title"
                placeholder="e.g., How do I solve quadratic equations?"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                maxLength={200}
                className="h-10"
              />
              <p className="text-xs text-muted-foreground">
                Summarize your question in a clear, descriptive title
              </p>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="body" className="text-sm font-medium">Question Details</Label>
              <Textarea
                id="body"
                placeholder="Explain your question in detail. Include what you've tried, what you know, and what you're confused about..."
                value={body}
                onChange={(e) => setBody(e.target.value)}
                required
                rows={7}
                className="resize-none text-sm"
              />
              <p className="text-xs text-muted-foreground">
                More detail = better answers
              </p>
            </div>

            {/* Anonymous toggle */}
            <div className="flex items-center justify-between p-4 rounded-xl bg-muted/30 border border-border/50">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Shield className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <Label htmlFor="anonymous" className="text-sm font-medium cursor-pointer">
                    Post Anonymously
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Your name will be hidden from this question
                  </p>
                </div>
              </div>
              <Switch
                id="anonymous"
                checked={isAnonymous}
                onCheckedChange={setIsAnonymous}
              />
            </div>

            <div className="flex gap-3 pt-1">
              <Button type="submit" disabled={loading} className="flex-1 bg-primary hover:bg-primary/90 shadow-md shadow-primary/20">
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Post Question
              </Button>
              <Button type="button" variant="outline" asChild>
                <Link href="/questions">Cancel</Link>
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
