import { createClient } from "@/lib/supabase/server"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardTitle } from "@/components/ui/card"
import { QuestionCard } from "@/components/questions/question-card"
import { HelpCircle, Plus } from "lucide-react"

export default async function MyQuestionsPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: questions } = await supabase
    .from("questions")
    .select(`
      *,
      profile:profiles!questions_user_id_fkey(id, full_name, role)
    `)
    .eq("user_id", user?.id)
    .order("created_at", { ascending: false })

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">My Questions</h1>
          <p className="text-muted-foreground">View and manage questions you have asked</p>
        </div>
        <Button asChild>
          <Link href="/questions/ask">
            <Plus className="h-4 w-4 mr-2" />
            Ask Question
          </Link>
        </Button>
      </div>

      {questions && questions.length > 0 ? (
        <div className="space-y-4">
          {questions.map((question) => (
            <QuestionCard key={question.id} question={question} currentUserId={user?.id} />
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <HelpCircle className="h-12 w-12 text-muted-foreground mb-4" />
            <CardTitle className="mb-2">No questions yet</CardTitle>
            <CardDescription className="text-center mb-4">
              {"You haven't asked any questions yet. Start by asking your first question!"}
            </CardDescription>
            <Button asChild>
              <Link href="/questions/ask">Ask Your First Question</Link>
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
