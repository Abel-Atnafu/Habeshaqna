"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"
import { Loader2, Send } from "lucide-react"

interface AnswerFormProps {
  questionId: string
}

export function AnswerForm({ questionId }: AnswerFormProps) {
  const [body, setBody] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)

    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      setError("You must be logged in to answer")
      setLoading(false)
      return
    }

    const { error: insertError } = await supabase
      .from("answers")
      .insert({ question_id: questionId, user_id: user.id, body })

    if (insertError) {
      setError(insertError.message)
      setLoading(false)
      return
    }

    setBody("")
    setLoading(false)
    router.refresh()
  }

  return (
    <Card className="border-border/60">
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Your Answer</CardTitle>
        <CardDescription className="text-xs">
          Share your knowledge and help others learn
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-3">
          {error && (
            <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm">
              {error}
            </div>
          )}
          <Textarea
            placeholder="Write a clear and helpful answer..."
            value={body}
            onChange={(e) => setBody(e.target.value)}
            required
            rows={5}
            className="resize-none text-sm"
          />
          <div className="flex justify-end">
            <Button type="submit" size="sm" disabled={loading || !body.trim()} className="gap-1.5">
              {loading ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Send className="h-3.5 w-3.5" />
              )}
              Post Answer
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
