"use client"

import { useState, useEffect } from "react"
import { formatDistanceToNow } from "date-fns"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { VoteButtons } from "@/components/questions/vote-buttons"
import { createClient } from "@/lib/supabase/client"
import { Check } from "lucide-react"
import type { Answer, Profile } from "@/lib/types"
import { cn } from "@/lib/utils"

interface AnswerWithProfile extends Answer {
  profile: Profile | null
}

interface AnswerCardProps {
  answer: AnswerWithProfile
  questionUserId: string
  currentUserId?: string
}

export function AnswerCard({ answer, questionUserId, currentUserId }: AnswerCardProps) {
  const [voteScore, setVoteScore] = useState(0)
  const [userVote, setUserVote] = useState(0)
  const [isAccepted, setIsAccepted] = useState(answer.is_accepted)
  const [loading, setLoading] = useState(false)

  const displayName = answer.profile?.full_name || "Unknown User"
  const initials = displayName.slice(0, 1).toUpperCase()
  const isTeacher = answer.profile?.role === "teacher"
  const isQuestionOwner = currentUserId === questionUserId
  const isAnswerOwner = currentUserId === answer.user_id

  useEffect(() => {
    async function fetchVotes() {
      const supabase = createClient()

      const { data: votes } = await supabase
        .from("votes")
        .select("value")
        .eq("answer_id", answer.id)

      const score = votes?.reduce((sum, vote) => sum + vote.value, 0) || 0
      setVoteScore(score)

      if (currentUserId) {
        const { data: myVote } = await supabase
          .from("votes")
          .select("value")
          .eq("answer_id", answer.id)
          .eq("user_id", currentUserId)
          .single()
        setUserVote(myVote?.value || 0)
      }
    }

    fetchVotes()
  }, [answer.id, currentUserId])

  async function handleAccept() {
    setLoading(true)
    const supabase = createClient()

    await supabase
      .from("answers")
      .update({ is_accepted: false })
      .eq("question_id", answer.question_id)

    const { error } = await supabase
      .from("answers")
      .update({ is_accepted: true })
      .eq("id", answer.id)

    if (!error) {
      setIsAccepted(true)
      await supabase
        .from("questions")
        .update({ status: "answered" })
        .eq("id", answer.question_id)
    }

    setLoading(false)
  }

  return (
    <Card className={cn(
      "transition-all duration-200",
      isAccepted
        ? "border-success/50 bg-success/5 shadow-md shadow-success/10"
        : "border-border/60"
    )}>
      <CardContent className="p-5">
        <div className="flex gap-4">
          <VoteButtons
            type="answer"
            id={answer.id}
            score={voteScore}
            userVote={userVote}
            isLoggedIn={!!currentUserId}
          />
          <div className="flex-1 min-w-0">
            {/* Author row */}
            <div className="flex items-center gap-2 mb-3">
              <div className={cn(
                "w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold shrink-0",
                isTeacher ? "bg-accent/20 text-accent" : "bg-primary/10 text-primary"
              )}>
                {initials}
              </div>
              <span className="text-sm font-medium">
                {displayName}
                {isAnswerOwner && (
                  <span className="text-muted-foreground font-normal"> (you)</span>
                )}
              </span>
              {isTeacher && (
                <Badge variant="secondary" className="text-xs h-4 px-1.5 py-0">Teacher</Badge>
              )}
              {isAccepted && (
                <Badge className="bg-success hover:bg-success/90 text-success-foreground h-5 px-2 text-xs gap-1">
                  <Check className="h-3 w-3" />
                  Accepted
                </Badge>
              )}
              <span className="text-xs text-muted-foreground ml-auto">
                {formatDistanceToNow(new Date(answer.created_at), { addSuffix: true })}
              </span>
            </div>

            {/* Answer body */}
            <p className="text-sm leading-relaxed whitespace-pre-wrap text-foreground/90">
              {answer.body}
            </p>

            {/* Accept button */}
            {isQuestionOwner && !isAccepted && (
              <div className="flex justify-end mt-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleAccept}
                  disabled={loading}
                  className="text-success border-success/30 hover:bg-success/10 hover:border-success/50 h-8 text-xs gap-1.5"
                >
                  <Check className="h-3.5 w-3.5" />
                  Accept Answer
                </Button>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
