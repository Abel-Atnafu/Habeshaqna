"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ChevronUp, ChevronDown } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { cn } from "@/lib/utils"

interface VoteButtonsProps {
  type: "question" | "answer"
  id: string
  score: number
  userVote: number
  isLoggedIn: boolean
}

export function VoteButtons({ type, id, score, userVote, isLoggedIn }: VoteButtonsProps) {
  const [currentScore, setCurrentScore] = useState(score)
  const [currentVote, setCurrentVote] = useState(userVote)
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  async function handleVote(value: 1 | -1) {
    if (!isLoggedIn) {
      router.push("/auth/login")
      return
    }

    setLoading(true)
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      setLoading(false)
      return
    }

    const voteData = type === "question"
      ? { user_id: user.id, question_id: id, value }
      : { user_id: user.id, answer_id: id, value }

    if (currentVote === value) {
      // Remove vote
      const { error } = await supabase
        .from("votes")
        .delete()
        .eq("user_id", user.id)
        .eq(type === "question" ? "question_id" : "answer_id", id)

      if (!error) {
        setCurrentScore(currentScore - value)
        setCurrentVote(0)
      }
    } else if (currentVote !== 0) {
      // Change vote
      const { error } = await supabase
        .from("votes")
        .update({ value })
        .eq("user_id", user.id)
        .eq(type === "question" ? "question_id" : "answer_id", id)

      if (!error) {
        setCurrentScore(currentScore - currentVote + value)
        setCurrentVote(value)
      }
    } else {
      // New vote
      const { error } = await supabase
        .from("votes")
        .insert(voteData)

      if (!error) {
        setCurrentScore(currentScore + value)
        setCurrentVote(value)
      }
    }

    setLoading(false)
  }

  return (
    <div className="flex flex-col items-center gap-1">
      <Button
        variant="ghost"
        size="icon"
        className={cn(
          "h-8 w-8",
          currentVote === 1 && "text-primary bg-primary/10"
        )}
        onClick={() => handleVote(1)}
        disabled={loading}
      >
        <ChevronUp className="h-5 w-5" />
      </Button>
      <span className={cn(
        "text-lg font-semibold",
        currentScore > 0 && "text-primary",
        currentScore < 0 && "text-destructive"
      )}>
        {currentScore}
      </span>
      <Button
        variant="ghost"
        size="icon"
        className={cn(
          "h-8 w-8",
          currentVote === -1 && "text-destructive bg-destructive/10"
        )}
        onClick={() => handleVote(-1)}
        disabled={loading}
      >
        <ChevronDown className="h-5 w-5" />
      </Button>
    </div>
  )
}
