import Link from "next/link"
import { formatDistanceToNow } from "date-fns"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MessageCircle, ChevronUp, Eye } from "lucide-react"
import type { Question, Profile } from "@/lib/types"
import { cn } from "@/lib/utils"

interface QuestionWithProfile extends Question {
  profile: Profile | null
}

interface QuestionCardProps {
  question: QuestionWithProfile
  currentUserId?: string
}

export function QuestionCard({ question, currentUserId }: QuestionCardProps) {
  const isOwner = currentUserId === question.user_id
  const displayName = question.is_anonymous
    ? "Anonymous"
    : question.profile?.full_name || "Unknown User"
  const initials = displayName.slice(0, 1).toUpperCase()
  const isTeacher = question.profile?.role === "teacher"
  const voteScore = question.vote_score || 0

  return (
    <Card className="group hover:border-border transition-all duration-200 hover:shadow-lg hover:shadow-black/10 overflow-hidden">
      <Link href={`/questions/${question.id}`}>
        <CardContent className="p-5">
          <div className="flex gap-4">
            {/* Vote score column */}
            <div className="flex flex-col items-center gap-1 pt-0.5 shrink-0">
              <div className={cn(
                "flex flex-col items-center gap-0.5 px-2.5 py-1.5 rounded-lg border text-center min-w-[48px]",
                voteScore > 0
                  ? "border-primary/30 bg-primary/5 text-primary"
                  : voteScore < 0
                  ? "border-destructive/30 bg-destructive/5 text-destructive"
                  : "border-border/60 bg-muted/30 text-muted-foreground"
              )}>
                <ChevronUp className="h-3 w-3" />
                <span className="text-sm font-bold leading-none">{voteScore}</span>
              </div>
              <div className="flex items-center gap-1 text-muted-foreground mt-1">
                <MessageCircle className="h-3 w-3" />
                <span className="text-xs">{question.answers_count || 0}</span>
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-3 mb-1.5">
                <h3 className="font-semibold text-base leading-snug group-hover:text-primary transition-colors line-clamp-2">
                  {question.title}
                </h3>
                {question.status !== "open" && (
                  <Badge
                    variant={question.status === "answered" ? "default" : "secondary"}
                    className="shrink-0 text-xs"
                  >
                    {question.status === "answered" ? "Answered" : "Closed"}
                  </Badge>
                )}
              </div>

              <p className="text-sm text-muted-foreground line-clamp-2 mb-3 leading-relaxed">
                {question.body}
              </p>

              {/* Footer */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className={cn(
                    "w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold shrink-0",
                    isTeacher
                      ? "bg-accent/20 text-accent"
                      : "bg-primary/10 text-primary"
                  )}>
                    {initials}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-muted-foreground font-medium">
                      {displayName}
                      {isOwner && !question.is_anonymous && (
                        <span className="text-muted-foreground/60"> (you)</span>
                      )}
                    </span>
                    {isTeacher && !question.is_anonymous && (
                      <Badge variant="secondary" className="text-xs h-4 px-1.5 py-0">Teacher</Badge>
                    )}
                  </div>
                </div>
                <span className="text-xs text-muted-foreground/60 shrink-0">
                  {formatDistanceToNow(new Date(question.created_at), { addSuffix: true })}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Link>
    </Card>
  )
}
