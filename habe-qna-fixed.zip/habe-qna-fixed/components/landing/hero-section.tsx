"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles, Play } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative py-24 md:py-40 overflow-hidden">
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-5xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-button text-sm font-medium mb-8 animate-reveal-up">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-success"></span>
            </span>
            <span className="text-muted-foreground">Free for students and teachers</span>
            <Sparkles className="h-3.5 w-3.5 text-primary" />
          </div>

          {/* Main headline */}
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight mb-8 animate-reveal-up" style={{ animationDelay: '0.1s' }}>
            <span className="block text-foreground">Ask Questions,</span>
            <span className="block gradient-text mt-2">Share Knowledge</span>
          </h1>

          {/* Subheadline */}
          <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto text-pretty leading-relaxed animate-reveal-up" style={{ animationDelay: '0.2s' }}>
            A safe and anonymous platform for Ethiopian students and teachers to ask questions, share knowledge, and learn together. No question is too simple.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-reveal-up" style={{ animationDelay: '0.3s' }}>
            <Button size="lg" className="w-full sm:w-auto h-14 px-8 text-base bg-primary hover:bg-primary/90 text-primary-foreground shadow-xl shadow-primary/30 hover:shadow-primary/50 transition-all hover:scale-105" asChild>
              <Link href="/auth/sign-up">
                Start Learning Today
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="w-full sm:w-auto h-14 px-8 text-base border-border/50 hover:bg-secondary/50 backdrop-blur-sm" asChild>
              <Link href="/questions">
                <Play className="mr-2 h-4 w-4" />
                Browse Questions
              </Link>
            </Button>
          </div>

          {/* Stats */}
          <div className="mt-16 md:mt-24 grid grid-cols-3 gap-8 max-w-2xl mx-auto animate-reveal-up" style={{ animationDelay: '0.4s' }}>
            {[
              { value: "10K+", label: "Questions Asked" },
              { value: "5K+", label: "Active Users" },
              { value: "98%", label: "Response Rate" },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-3xl md:text-4xl font-bold gradient-text">{stat.value}</div>
                <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Preview Card */}
        <div className="mt-20 md:mt-32 relative animate-reveal-up" style={{ animationDelay: '0.5s' }}>
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent z-10 pointer-events-none h-32 bottom-0 top-auto" />
          
          <div className="glass-card rounded-2xl overflow-hidden max-w-4xl mx-auto shadow-2xl shadow-black/40 card-hover">
            {/* Browser chrome */}
            <div className="border-b border-border/50 bg-secondary/30 px-4 py-3 flex items-center gap-3">
              <div className="flex gap-2">
                <div className="w-3 h-3 rounded-full bg-destructive/70" />
                <div className="w-3 h-3 rounded-full bg-warning/70" />
                <div className="w-3 h-3 rounded-full bg-success/70" />
              </div>
              <div className="flex-1 flex justify-center">
                <div className="px-4 py-1 rounded-lg bg-muted/50 text-xs text-muted-foreground">
                  habeqna.app/dashboard
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="p-6 space-y-4">
              {/* Question 1 */}
              <div className="flex items-start gap-4 p-5 rounded-xl bg-muted/30 border border-border/50 hover:border-primary/30 transition-colors">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center shrink-0">
                  <span className="text-primary font-semibold">A</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-medium text-foreground">Anonymous Student</span>
                    <span className="text-xs text-muted-foreground">2 hours ago</span>
                  </div>
                  <h3 className="font-semibold text-lg mb-1 text-foreground">How do I solve quadratic equations?</h3>
                  <p className="text-sm text-muted-foreground">{"I'm having trouble understanding the quadratic formula. Can someone explain it step by step?"}</p>
                </div>
                <div className="flex flex-col items-center gap-1 px-3">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    <span className="text-primary font-bold">12</span>
                  </div>
                  <span className="text-xs text-muted-foreground">votes</span>
                </div>
              </div>

              {/* Question 2 */}
              <div className="flex items-start gap-4 p-5 rounded-xl bg-muted/30 border border-border/50 hover:border-accent/30 transition-colors">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-accent/30 to-accent/10 flex items-center justify-center shrink-0">
                  <span className="text-accent font-semibold">T</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-medium text-foreground">Teacher Abebe</span>
                    <span className="px-2 py-0.5 rounded-full bg-accent/20 text-accent text-xs font-medium">Teacher</span>
                    <span className="text-xs text-muted-foreground">1 hour ago</span>
                  </div>
                  <h3 className="font-semibold text-lg mb-1 text-foreground">What are the best study techniques for biology?</h3>
                  <p className="text-sm text-muted-foreground">Looking for effective methods to help my students memorize complex biological processes.</p>
                </div>
                <div className="flex flex-col items-center gap-1 px-3">
                  <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center">
                    <span className="text-accent font-bold">8</span>
                  </div>
                  <span className="text-xs text-muted-foreground">votes</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
