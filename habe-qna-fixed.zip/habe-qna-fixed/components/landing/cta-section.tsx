"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles, Users, MessageCircleQuestion } from "lucide-react"

export function CTASection() {
  return (
    <section className="py-32 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] rounded-full bg-primary/15 blur-[120px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[400px] h-[400px] rounded-full bg-accent/10 blur-[100px] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto">
          <div className="glass-card rounded-3xl p-12 md:p-16 text-center relative overflow-hidden">
            {/* Inner glow */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10 rounded-3xl" />
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-px bg-gradient-to-r from-transparent via-primary/60 to-transparent" />

            <div className="relative z-10">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-button text-sm font-medium mb-8">
                <Sparkles className="h-4 w-4 text-primary" />
                <span className="text-muted-foreground">Join the community today</span>
              </div>

              {/* Headline */}
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance">
                Ready to Start{" "}
                <span className="gradient-text">Learning?</span>
              </h2>

              <p className="text-muted-foreground text-lg mb-10 max-w-2xl mx-auto leading-relaxed">
                Join thousands of Ethiopian students and teachers who are already asking questions,
                sharing knowledge, and growing together on Habeqna.
              </p>

              {/* Social proof stats */}
              <div className="flex items-center justify-center gap-8 mb-10">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Users className="h-4 w-4 text-primary" />
                  <span><strong className="text-foreground">5,000+</strong> active users</span>
                </div>
                <div className="w-px h-4 bg-border" />
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MessageCircleQuestion className="h-4 w-4 text-accent" />
                  <span><strong className="text-foreground">10,000+</strong> questions answered</span>
                </div>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button
                  size="lg"
                  className="w-full sm:w-auto h-14 px-10 text-base bg-primary hover:bg-primary/90 text-primary-foreground shadow-xl shadow-primary/30 hover:shadow-primary/50 transition-all hover:scale-105"
                  asChild
                >
                  <Link href="/auth/sign-up">
                    Get Started Free
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="w-full sm:w-auto h-14 px-10 text-base border-border/50 hover:bg-secondary/50"
                  asChild
                >
                  <Link href="/auth/login">
                    Sign In
                  </Link>
                </Button>
              </div>

              <p className="text-xs text-muted-foreground mt-6">
                Free forever for students and teachers. No credit card required.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
