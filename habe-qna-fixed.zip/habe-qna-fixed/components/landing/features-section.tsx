"use client"

import { MessageCircleQuestion, Shield, Users, Zap, Globe, Award } from "lucide-react"

const features = [
  {
    icon: MessageCircleQuestion,
    title: "Ask Anything",
    description: "No question is too simple or too complex. Get answers from teachers and fellow students in a supportive environment.",
    gradient: "from-primary/20 to-primary/5",
    iconColor: "text-primary",
  },
  {
    icon: Shield,
    title: "Stay Anonymous",
    description: "Ask questions anonymously when you need privacy. Your identity is always protected when you choose.",
    gradient: "from-accent/20 to-accent/5",
    iconColor: "text-accent",
  },
  {
    icon: Users,
    title: "Community Driven",
    description: "Vote on the best answers and help others learn. Everyone contributes to building knowledge.",
    gradient: "from-success/20 to-success/5",
    iconColor: "text-success",
  },
  {
    icon: Zap,
    title: "Quick Responses",
    description: "Get answers fast from an active community of educators and learners who care about your success.",
    gradient: "from-warning/20 to-warning/5",
    iconColor: "text-warning",
  },
  {
    icon: Globe,
    title: "Built for Ethiopia",
    description: "Designed specifically for the Ethiopian education community, with local context and understanding.",
    gradient: "from-chart-4/20 to-chart-4/5",
    iconColor: "text-chart-4",
  },
  {
    icon: Award,
    title: "Quality Verified",
    description: "Teacher-verified answers help you know which responses are most accurate and reliable.",
    gradient: "from-chart-2/20 to-chart-2/5",
    iconColor: "text-chart-2",
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="py-32 relative">
      {/* Background accent */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-muted/30 to-transparent" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <span className="inline-block px-4 py-1.5 rounded-full glass-button text-xs font-medium text-primary uppercase tracking-wider mb-6">
            Features
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance">
            Why Choose <span className="gradient-text">Habeqna</span>?
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto text-pretty">
            Built specifically for the Ethiopian education community, making learning accessible to everyone.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="group relative p-8 rounded-2xl glass-card card-hover"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Gradient background on hover */}
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
              
              <div className="relative z-10">
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className={`w-7 h-7 ${feature.iconColor}`} />
                </div>
                <h3 className="font-semibold text-xl mb-3 text-foreground">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
