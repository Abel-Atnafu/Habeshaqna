"use client"

import { Star, Quote } from "lucide-react"

const testimonials = [
  {
    quote: "Habeqna changed how I approach learning. I used to be afraid to ask questions in class, but here I can ask anything anonymously.",
    author: "Meron T.",
    role: "Grade 12 Student",
    avatar: "M",
    rating: 5,
  },
  {
    quote: "As a teacher, I love seeing students help each other. The platform makes it easy to provide verified answers and guide discussions.",
    author: "Ato Bekele",
    role: "Math Teacher",
    avatar: "B",
    rating: 5,
  },
  {
    quote: "The community here is incredibly supportive. I got detailed explanations for physics problems that my textbook didn't cover well.",
    author: "Daniel K.",
    role: "University Student",
    avatar: "D",
    rating: 5,
  },
]

export function TestimonialsSection() {
  return (
    <section id="testimonials" className="py-32 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-muted/20 to-transparent" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <span className="inline-block px-4 py-1.5 rounded-full glass-button text-xs font-medium text-success uppercase tracking-wider mb-6">
            Community
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance">
            Loved by <span className="gradient-text">Students & Teachers</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Join thousands of learners who are already transforming their educational journey with Habeqna.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="relative p-8 rounded-2xl glass-card card-hover group"
            >
              {/* Quote icon */}
              <Quote className="absolute top-6 right-6 w-8 h-8 text-primary/20 group-hover:text-primary/40 transition-colors" />
              
              {/* Rating */}
              <div className="flex gap-1 mb-6">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-warning text-warning" />
                ))}
              </div>

              {/* Quote */}
              <p className="text-foreground mb-8 leading-relaxed text-lg">
                &ldquo;{testimonial.quote}&rdquo;
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center">
                  <span className="text-foreground font-semibold">{testimonial.avatar}</span>
                </div>
                <div>
                  <div className="font-semibold text-foreground">{testimonial.author}</div>
                  <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
