"use client"

const steps = [
  {
    number: "01",
    title: "Create Your Account",
    description: "Sign up as a student or teacher in seconds. Choose your role and join our growing community of learners.",
    highlight: "30 seconds to sign up",
  },
  {
    number: "02", 
    title: "Ask or Explore",
    description: "Post your questions or browse existing ones. Use anonymous mode if you prefer complete privacy.",
    highlight: "10K+ questions available",
  },
  {
    number: "03",
    title: "Learn & Grow",
    description: "Receive thoughtful answers from teachers and peers. Vote on the most helpful responses and build your knowledge.",
    highlight: "98% questions answered",
  },
]

export function HowItWorksSection() {
  return (
    <section id="how-it-works" className="py-32 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-1/2 left-0 w-96 h-96 rounded-full bg-primary/10 blur-[120px] -translate-y-1/2" />
      <div className="absolute top-1/2 right-0 w-96 h-96 rounded-full bg-accent/10 blur-[120px] -translate-y-1/2" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <span className="inline-block px-4 py-1.5 rounded-full glass-button text-xs font-medium text-accent uppercase tracking-wider mb-6">
            How It Works
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance">
            Start Learning in <span className="gradient-text-accent">Minutes</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Getting started with Habeqna is simple. Join thousands of students and teachers already learning together.
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 md:gap-12 relative">
            {/* Connecting line */}
            <div className="hidden md:block absolute top-16 left-[16%] right-[16%] h-px bg-gradient-to-r from-primary/50 via-accent/50 to-primary/50" />
            
            {steps.map((step, index) => (
              <div key={step.number} className="relative">
                {/* Step number circle */}
                <div className="relative z-10 mb-8 flex justify-center">
                  <div className="w-32 h-32 rounded-full glass-card flex items-center justify-center group hover:scale-105 transition-transform duration-300">
                    <span className="text-5xl font-bold gradient-text">{step.number}</span>
                    <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </div>
                </div>
                
                <div className="text-center">
                  <h3 className="font-semibold text-2xl mb-4 text-foreground">{step.title}</h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">{step.description}</p>
                  <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
                    {step.highlight}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
