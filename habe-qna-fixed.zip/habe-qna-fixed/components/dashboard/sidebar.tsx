"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Home, MessageCircleQuestion, User, HelpCircle } from "lucide-react"

const navigation = [
  { name: "Dashboard", href: "/dashboard", icon: Home, exact: true },
  { name: "All Questions", href: "/questions", icon: MessageCircleQuestion, exact: false },
  { name: "My Questions", href: "/my-questions", icon: HelpCircle, exact: false },
  { name: "Profile", href: "/profile", icon: User, exact: false },
]

export function DashboardSidebar() {
  const pathname = usePathname()

  return (
    <aside className="hidden md:flex w-60 flex-col border-r border-border/50 bg-sidebar">
      <nav className="flex-1 p-3 space-y-0.5 pt-4">
        {navigation.map((item) => {
          const isActive = item.exact
            ? pathname === item.href
            : pathname === item.href || pathname.startsWith(item.href + "/")

          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200",
                isActive
                  ? "bg-primary/15 text-primary shadow-sm shadow-primary/10"
                  : "text-muted-foreground hover:bg-muted/60 hover:text-foreground"
              )}
            >
              <item.icon className={cn("h-4 w-4 flex-shrink-0", isActive && "text-primary")} />
              {item.name}
              {isActive && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary" />
              )}
            </Link>
          )
        })}
      </nav>

      <div className="p-4 border-t border-border/50">
        <div className="px-3 py-2.5 rounded-xl bg-primary/5 border border-primary/10">
          <p className="text-xs text-muted-foreground leading-relaxed">
            Share knowledge. Help others learn together.
          </p>
        </div>
      </div>
    </aside>
  )
}
